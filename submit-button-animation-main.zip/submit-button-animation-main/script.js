const btn = document.querySelector("[data-btn]")
btn.addEventListener("click", () => {
  btn.classList.add("animating")
})
